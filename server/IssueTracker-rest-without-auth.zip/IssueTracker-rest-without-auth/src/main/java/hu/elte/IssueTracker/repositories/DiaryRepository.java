package hu.elte.IssueTracker.repositories;

import hu.elte.IssueTracker.entities.Diary;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DiaryRepository extends CrudRepository<Diary, Integer> {
    
}
