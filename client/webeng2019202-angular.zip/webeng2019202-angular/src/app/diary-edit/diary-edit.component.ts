import { Component, OnInit } from '@angular/core';
import { DiaryService } from '../diary.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Diary } from '../diary';
import { Location } from '@angular/common';

@Component({
  selector: 'app-diary-edit',
  templateUrl: './diary-edit.component.html',
  styleUrls: ['./diary-edit.component.css']
})
export class DiaryEditComponent implements OnInit {

  diary: Diary = new Diary();
  id: number = null;

  constructor(
    private route: ActivatedRoute,
    private diaryService: DiaryService,
    private location: Location,
    private router: Router
  ) { }

  async ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.id = +id;
      this.diary = await this.diaryService.getDiary(this.id);
    }
  }

  async handleSave(formData: Diary) {
   
    if (this.id) {
      await this.diaryService.modifyDiary(this.id, formData);
      this.location.back();
    } else {
      await this.diaryService.addDiary(formData);
      this.router.navigate(['issues']);
    }
  }
}
