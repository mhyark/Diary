import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import { Diary } from '../diary';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-diary-form',
  templateUrl: './diary-form.component.html',
  styleUrls: ['./diary-form.component.css']
})
export class DiaryFormComponent implements OnInit, OnChanges {

  @Input() diary: Diary;
  @Output() save = new EventEmitter<Diary>();

  diaryForm = this.fb.group({
    title: ['', [Validators.required]],
    description: ['', [Validators.required]],
    created_at: ['', [Validators.required]],
  })
  get title() { return this.diaryForm.get('title'); }
  get description() { return this.diaryForm.get('description'); }
  get created_at() { return this.diaryForm.get('created_at'); }
  
   
  constructor(
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    //this.diaryForm.get('created_at').setValue(this.diary.created_at);
    //this.diary.created_at = new Date(Date.parse(Date()))
  }

  ngOnChanges() {
    this.diaryForm.markAsUntouched();
    this.diaryForm.patchValue(this.diary);
  }

  onSubmit() {
    if (this.diaryForm.valid) {
      this.save.emit(this.diaryForm.value);
    }
  }

}