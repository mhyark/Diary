export class Diary {
  id: number;
  title = '';
  description = '';
  created_at = new Date(Date.parse(Date()));
}
