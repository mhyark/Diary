
import { Component, OnInit } from '@angular/core';
import { Diary } from '../diary';
import { DiaryService } from '../diary.service';

@Component({
  selector: 'app-important-diaries',
  templateUrl: './important-diaries.component.html',
  styleUrls: ['./important-diaries.component.css']
})
export class ImportantDiariesComponent implements OnInit {

  diaries: Diary[] = [];
  importantdiaries: Diary[] = [];
   sortedActivities: Diary[] = [];
  
  status = 'ALL';
  // filteredIssues: Issue[] = this.issues;
  filteredDiaries: Diary[] = [];
  selectedDiary: Diary = null;

  constructor(
    private diaryService: DiaryService
  ) { }

  async ngOnInit() {
    // this.filteredIssues = this.issues;

    // this.filteredIssues = this.status === 'ALL'
    //   ? this.issues
    //   : this.issues.filter(issue => issue.status === this.status);
  
    this.diaries = await this.diaryService.getDiaries();
  
    this.sortData();

    // this.filterEvents();
  
  }
   sortData() {
    return this.diaries.sort((a, b) => {
      return <any>new Date(b.created_at) - <any>new Date(a.created_at);
    });
  }


  filterEvents() {
    // this.filterEvents = this.status === 'ALL'
    //   ? this.events
    //   : this.events.filter(event => event.status === this.status);
  }

  handleStatusChange(status) {
    this.status = status;
    this.filterEvents();
  }

  handleSave(event) {
    Object.assign(this.selectedDiary, event);
    this.selectedDiary = null;
  }

}

