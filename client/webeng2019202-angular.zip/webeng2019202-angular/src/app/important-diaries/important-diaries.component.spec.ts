
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportantDiariesComponent } from './important-diaries.component';

describe('ImportantEventsComponent', () => {
  let component: ImportantDiariesComponent;
  let fixture: ComponentFixture<ImportantDiariesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportantDiariesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportantDiariesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
