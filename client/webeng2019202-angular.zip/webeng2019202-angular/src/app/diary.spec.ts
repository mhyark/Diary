import { Diary } from './diary';

describe('Diary', () => {
  it('should create an instance', () => {
    expect(new Diary()).toBeTruthy();
  });
});
