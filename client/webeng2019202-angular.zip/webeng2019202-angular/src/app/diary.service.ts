import { Injectable } from '@angular/core';
import { Diary } from './diary';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
    // Authorization: 'Basic dXNlcjpwYXNzd29yZA==',
  })
};

@Injectable({
  providedIn: 'root'
})
export class DiaryService {

  private diaryUrl = '/api/diaries';

  constructor(
    private http: HttpClient
  ) { }

  getDiaries() {
    // return this.issues;
    return this.http.get<Diary[]>(`${this.diaryUrl}`, httpOptions).toPromise();
  }

  getDiary(id: number) {
    // return this.issues.find(issue => issue.id === id);
    return this.http.get<Diary>(`${this.diaryUrl}/${id}`, httpOptions).toPromise();
  }

  modifyDiary(id: number, data) {
   
    return this.http.put<Diary>(`${this.diaryUrl}/${id}`, data, httpOptions).toPromise();
  }

  addDiary(diary:Diary):Promise<Diary> {
    return this.http.post<Diary>(`${this.diaryUrl}`, diary, httpOptions).toPromise();
  }

  deleteDiary(id: number) {
    return this.http.delete<Diary>(`${this.diaryUrl}/${id}`, httpOptions).toPromise();
  }
}
