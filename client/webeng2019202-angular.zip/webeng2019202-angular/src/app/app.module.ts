import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainPageComponent } from './main-page/main-page.component';
import { StatusFilterComponent } from './status-filter/status-filter.component';
import { LoginComponent } from './login/login.component';
import { AuthInterceptor } from './auth-interceptor';
import { AboutComponent } from './about/about.component';
import { DiaryDetailComponent } from './diary-detail/diary-detail.component';
import { DiaryEditComponent } from './diary-edit/diary-edit.component';
import { DiaryFormComponent } from './diary-form/diary-form.component';
import { DiaryListComponent } from './diary-list/diary-list.component';
import { DiaryNewComponent } from './diary-new/diary-new.component';
import { ImportantDiariesComponent } from './important-diaries/important-diaries.component';

@NgModule({
  declarations: [
    AppComponent,
    MainPageComponent,
    StatusFilterComponent,
    LoginComponent,
    AboutComponent,
    DiaryListComponent,
    DiaryDetailComponent,
    DiaryFormComponent,
    DiaryEditComponent,
    DiaryNewComponent,
    ImportantDiariesComponent,
    
  ],
  imports: [
    NgbModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
