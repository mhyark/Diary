import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DiaryService } from '../diary.service';
import { Diary } from '../diary';
import { Location } from '@angular/common';

@Component({
  selector: 'app-diary-detail',
  templateUrl: './diary-detail.component.html',
  styleUrls: ['./diary-detail.component.css']
})
export class DiaryDetailComponent implements OnInit {

  diary: Diary = new Diary();

  constructor(
    private route: ActivatedRoute,
    private diaryService: DiaryService,
    // private location: Location
  ) { }

  async ngOnInit() {
    const id = +this.route.snapshot.paramMap.get('id');
    this.diary = await this.diaryService.getDiary(id);
  }

  // async onDelete() {
  //   await this.eventService.deleteEvent(this.event.id);
  //   this.location.back();
  // }

}
