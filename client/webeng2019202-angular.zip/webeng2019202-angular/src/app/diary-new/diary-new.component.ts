
import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import {  Diary } from '../diary';
import { FormBuilder, Validators } from '@angular/forms';
import { DiaryService } from '../diary.service';
import { ActivatedRoute, Router } from '@angular/router';

import { Location } from '@angular/common';

@Component({
  selector: 'app-diary-new',
  templateUrl: './diary-new.component.html',
  styleUrls: ['./diary-new.component.css']
})
export class DiaryNewComponent implements OnInit, OnChanges {

  @Input() diary: Diary;
  @Output() save = new EventEmitter<Diary>();

  diaryForm = this.fb.group({
    title: ['', [Validators.required]],
    description: ['', [Validators.required]],
    created_at: ['', [Validators.required]],
  });
  get title() { return this.diaryForm.get('title'); }
  get description() { return this.diaryForm.get('description'); }
  get created_at() { return this.diaryForm.get('created_at'); }

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private diaryService: DiaryService,
    // private location: Location,
    private router: Router
  ) { }





  ngOnInit(): void {
    // this.issueForm.get('title').setValue(this.issue.title);
  }

  ngOnChanges() {
    this.diaryForm.markAsUntouched();
    this.diaryForm.patchValue(this.diary);
  }

  async onSubmit() {
 
    if (this.diaryForm.valid) {
  
      // this.save.emit(this.eventForm.value);
      await this.diaryService.addDiary(this.diaryForm.value);
      this.router.navigate(['diaries']);
    }
  }
  // async handleSave(formData: Event) {
    
  //   if (this.id) {
  //     await this.eventService.modifyEvent(this.id, formData);
  //     this.router.navigate(['events']);
  //   } else {
  //     await this.eventService.addEvent(formData);
  //     this.router.navigate(['events']);
  //   }
  // }

}

