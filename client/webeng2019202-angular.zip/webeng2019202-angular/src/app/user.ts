export class User {
  username = 'Győző';
  role = 'USER';
}
