import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainPageComponent } from './main-page/main-page.component';

import { AuthGuard } from './auth.guard';
import { DiaryNewComponent } from './diary-new/diary-new.component';
import { DiaryListComponent } from './diary-list/diary-list.component';
import { DiaryDetailComponent } from './diary-detail/diary-detail.component';
import { DiaryEditComponent } from './diary-edit/diary-edit.component';
import {AboutComponent} from './about/about.component';


const routes: Routes = [
  {
    path: '',
    component: MainPageComponent
  },
  {
    path: 'about',
    component: AboutComponent,
    // canActivate: [AuthGuard],
  },
  {
    path: 'diaries',
    component: DiaryListComponent,
    // canActivate: [AuthGuard],
  },
  {
    path: 'diaries/new',
    component: DiaryNewComponent,
  },
  {
    path: 'diaries/:id',
    component: DiaryDetailComponent,
    // canActivate: [AuthGuard],
  },
  {
    path: 'diaries/:id/edit',
    component: DiaryEditComponent,
    // canActivate: [AuthGuard],
  },
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
