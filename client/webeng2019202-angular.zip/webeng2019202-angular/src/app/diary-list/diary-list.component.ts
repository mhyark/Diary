import { Component, OnInit } from '@angular/core';
import { Diary } from '../diary';
import { DiaryService } from '../diary.service';

@Component({
  selector: 'app-diary-list',
  templateUrl: './diary-list.component.html',
  styleUrls: ['./diary-list.component.css']
})
export class DiaryListComponent implements OnInit {

  diaries: Diary[] = [];
  status = 'ALL';
  // filteredIssues: Issue[] = this.issues;
  filteredDiaries: Diary[] = [];
  selectedDiary: Diary = null;

  constructor(
    private diaryService: DiaryService
  ) { }

  async ngOnInit() {
    // this.filteredIssues = this.issues;

    // this.filteredIssues = this.status === 'ALL'
    //   ? this.issues
    //   : this.issues.filter(issue => issue.status === this.status);

    this.diaries = await this.diaryService.getDiaries();
    this.filterDiaries();
  }

  filterDiaries() {
    // this.filterEvents = this.status === 'ALL'
    //   ? this.events
    //   : this.events.filter(event => event.status === this.status);
  }

  handleStatusChange(status) {
    this.status = status;
    this.filterDiaries();
  }

  handleSave(diary) {
    Object.assign(this.selectedDiary, diary);
    this.selectedDiary = null;
  }

}
